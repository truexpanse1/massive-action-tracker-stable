import React from 'react';

const AddAppointmentModal: React.FC = () => {
  return null; // This component appears to be unused. SetAppointmentModal is used instead.
};

export default AddAppointmentModal;
